from __future__ import annotations

NONE_STR = "None"
TRUE_STR = "True"
FALSE_STR = "False"
