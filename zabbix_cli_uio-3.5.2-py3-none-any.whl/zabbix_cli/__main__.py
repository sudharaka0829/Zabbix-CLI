from __future__ import annotations

from zabbix_cli.main import main

if __name__ == "__main__":
    main()
