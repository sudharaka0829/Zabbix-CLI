from __future__ import annotations

__version__ = "3.5.2"
APP_NAME = "zabbix-cli"
AUTHOR = "unioslo"
